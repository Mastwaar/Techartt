/**
 * Shared code between client and server
 * Useful to share types between client and server
 * and/or small pure JS functions that can be used on both client and server
 */

/**
 * Example response type for /api/demo
 */
export interface DemoResponse {
  message: string;
}

/**
 * Product variant interface
 */
export interface ProductVariant {
  id: string;
  name: string;
  value: string;
  stock?: number;
}

/**
 * Product interface
 */
export interface Product {
  id: string;
  name: string;
  price: number;
  description?: string;
  images: string[];
  variants?: {
    [key: string]: ProductVariant[];
  };
  vtonImage?: string;
  category?: string;
}

/**
 * Cart item with selected variants
 */
export interface CartItem {
  productId: string;
  product: Product;
  quantity: number;
  selectedVariants?: {
    [key: string]: string;
  };
}

/**
 * Applied product for avatar
 */
export interface AppliedProduct {
  productId: string;
  layer: "top" | "bottom" | "accessory";
  imageUrl: string;
}

/**
 * Checkout order payload
 */
export interface CheckoutOrderPayload {
  items: CartItem[];
  subtotal: number;
  tax: number;
  total: number;
  shippingAddress: {
    fullName: string;
    email: string;
    phone: string;
    addressLine1: string;
    addressLine2?: string;
    city: string;
    state: string;
    postalCode: string;
    country: string;
  };
  promoCode?: string;
  discount?: number;
}
