import React, { useState, useRef } from "react";
import { ZoomIn, ZoomOut, Upload, Eye, EyeOff } from "lucide-react";

interface VTONProduct {
  productId: string;
  overlayImage: string;
  name?: string;
}

interface VTONPreviewProps {
  userImage?: string;
  products: VTONProduct[];
  onUserImageUpload?: (image: string) => void;
  onProductToggle?: (productId: string, visible: boolean) => void;
}

export const VTONPreview: React.FC<VTONPreviewProps> = ({
  userImage,
  products,
  onUserImageUpload,
  onProductToggle,
}) => {
  const [zoom, setZoom] = useState(1);
  const [visibleProducts, setVisibleProducts] = useState<Set<string>>(
    new Set(products.map((p) => p.productId))
  );
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        const result = event.target?.result as string;
        onUserImageUpload?.(result);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleProductToggle = (productId: string) => {
    const newVisible = new Set(visibleProducts);
    if (newVisible.has(productId)) {
      newVisible.delete(productId);
    } else {
      newVisible.add(productId);
    }
    setVisibleProducts(newVisible);
    onProductToggle?.(productId, newVisible.has(productId));
  };

  const handleZoom = (delta: number) => {
    setZoom(Math.max(1, Math.min(3, zoom + delta)));
  };

  return (
    <div className="bg-white rounded-lg border border-slate-200 overflow-hidden">
      {/* Header */}
      <div className="p-6 border-b border-slate-200">
        <h3 className="text-lg font-semibold text-slate-900">Virtual Try-On Preview</h3>
        <p className="text-sm text-slate-600 mt-1">
          See how your selected items look on you
        </p>
      </div>

      {/* Main Content */}
      <div className="p-6">
        {/* Upload User Image */}
        {!userImage && (
          <div
            className="w-full aspect-square max-w-md mx-auto border-2 border-dashed border-slate-300 rounded-lg flex items-center justify-center bg-slate-50 hover:border-slate-400 transition-colors cursor-pointer group mb-6"
            onClick={() => fileInputRef.current?.click()}
          >
            <div className="text-center">
              <div className="inline-flex items-center justify-center w-12 h-12 rounded-lg bg-slate-200 group-hover:bg-slate-300 transition-colors mb-3">
                <Upload size={24} className="text-slate-600" />
              </div>
              <p className="font-medium text-slate-900">Upload your photo</p>
              <p className="text-sm text-slate-600 mt-1">
                Click to select an image to try items on
              </p>
            </div>
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              onChange={handleImageUpload}
              className="hidden"
            />
          </div>
        )}

        {/* Preview Canvas */}
        {userImage && (
          <div className="space-y-4">
            {/* Canvas Container */}
            <div className="w-full max-w-md mx-auto bg-slate-100 rounded-lg overflow-hidden border border-slate-200">
              <div
                className="relative overflow-hidden flex items-center justify-center"
                style={{
                  aspectRatio: "1",
                  transform: `scale(${zoom})`,
                  transformOrigin: "center",
                  transition: "transform 200ms ease-out",
                }}
              >
                {/* User Image Base */}
                <img
                  src={userImage}
                  alt="User"
                  className="w-full h-full object-cover absolute inset-0"
                />

                {/* Product Overlays */}
                {products.map(
                  (product) =>
                    visibleProducts.has(product.productId) && (
                      <img
                        key={product.productId}
                        src={product.overlayImage}
                        alt={product.name}
                        className="w-full h-full object-cover absolute inset-0"
                        style={{
                          mixBlendMode: "multiply",
                        }}
                      />
                    )
                )}
              </div>
            </div>

            {/* Controls */}
            <div className="flex items-center justify-center gap-2">
              <button
                onClick={() => handleZoom(-0.2)}
                disabled={zoom <= 1}
                className="p-2 border border-slate-200 rounded-lg hover:bg-slate-50 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                title="Zoom out"
              >
                <ZoomOut size={20} />
              </button>
              <span className="text-sm font-medium text-slate-600 w-12 text-center">
                {(zoom * 100).toFixed(0)}%
              </span>
              <button
                onClick={() => handleZoom(0.2)}
                disabled={zoom >= 3}
                className="p-2 border border-slate-200 rounded-lg hover:bg-slate-50 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                title="Zoom in"
              >
                <ZoomIn size={20} />
              </button>
              <button
                onClick={() => fileInputRef.current?.click()}
                className="ml-auto px-4 py-2 text-sm font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors flex items-center gap-2"
              >
                <Upload size={16} />
                Change Photo
              </button>
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                onChange={handleImageUpload}
                className="hidden"
              />
            </div>

            {/* Product Toggles */}
            {products.length > 0 && (
              <div className="bg-slate-50 rounded-lg p-4 border border-slate-200">
                <h4 className="text-sm font-semibold text-slate-900 mb-3">Show/Hide Items</h4>
                <div className="space-y-2">
                  {products.map((product) => (
                    <button
                      key={product.productId}
                      onClick={() => handleProductToggle(product.productId)}
                      className="w-full flex items-center justify-between p-3 rounded-lg border border-slate-200 hover:bg-white transition-colors group"
                    >
                      <span className="text-sm font-medium text-slate-700">
                        {product.name || `Product ${product.productId}`}
                      </span>
                      <div className="p-1.5 rounded-lg bg-slate-100 group-hover:bg-slate-200 transition-colors">
                        {visibleProducts.has(product.productId) ? (
                          <Eye size={16} className="text-slate-600" />
                        ) : (
                          <EyeOff size={16} className="text-slate-400" />
                        )}
                      </div>
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
