import React from "react";
import { CartItem } from "@shared/api";
import { X, ShoppingBag } from "lucide-react";
import { Button } from "@/components/ui/button";

interface CartProps {
  items: CartItem[];
  total: number;
  isOpen: boolean;
  onClose: () => void;
  onUpdateQuantity: (productId: string, quantity: number) => void;
  onRemoveItem: (productId: string) => void;
  onCheckout: () => void;
}

export const Cart: React.FC<CartProps> = ({
  items,
  total,
  isOpen,
  onClose,
  onUpdateQuantity,
  onRemoveItem,
  onCheckout,
}) => {
  if (!isOpen) return null;

  return (
    <>
      {/* Overlay */}
      <div
        className="fixed inset-0 bg-black/40 backdrop-blur-sm z-40 transition-opacity"
        onClick={onClose}
      />

      {/* Slide-over Panel */}
      <div className="fixed right-0 top-0 bottom-0 w-full max-w-md bg-white shadow-xl z-50 flex flex-col animate-in slide-in-from-right-80 duration-300">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-slate-200">
          <div className="flex items-center gap-2">
            <ShoppingBag className="text-slate-900" size={24} />
            <h2 className="text-xl font-semibold text-slate-900">Shopping Cart</h2>
          </div>
          <button
            onClick={onClose}
            className="p-2 hover:bg-slate-100 rounded-lg transition-colors"
          >
            <X size={20} />
          </button>
        </div>

        {/* Items List */}
        <div className="flex-1 overflow-y-auto">
          {items.length === 0 ? (
            <div className="p-6 text-center">
              <div className="inline-flex items-center justify-center w-12 h-12 rounded-lg bg-slate-100 mb-4">
                <ShoppingBag className="text-slate-400" size={24} />
              </div>
              <p className="text-slate-600 font-medium">Your cart is empty</p>
              <p className="text-sm text-slate-500 mt-1">
                Add items to get started
              </p>
            </div>
          ) : (
            <div className="divide-y divide-slate-100">
              {items.map((item) => (
                <div key={item.productId} className="p-4 hover:bg-slate-50 transition-colors">
                  <div className="flex gap-4">
                    {/* Product Image */}
                    <div className="w-20 h-20 bg-slate-100 rounded-lg overflow-hidden flex-shrink-0">
                      <img
                        src={item.product.images[0]}
                        alt={item.product.name}
                        className="w-full h-full object-cover"
                      />
                    </div>

                    {/* Product Info */}
                    <div className="flex-1 min-w-0">
                      <h3 className="font-medium text-slate-900 line-clamp-2 text-sm">
                        {item.product.name}
                      </h3>

                      {/* Variants */}
                      {item.selectedVariants && Object.entries(item.selectedVariants).length > 0 && (
                        <div className="mt-1">
                          {Object.entries(item.selectedVariants).map(([key, value]) => (
                            <p key={key} className="text-xs text-slate-500">
                              {key}: {value}
                            </p>
                          ))}
                        </div>
                      )}

                      <p className="text-sm font-semibold text-slate-900 mt-2">
                        ${item.product.price.toFixed(2)}
                      </p>

                      {/* Quantity and Remove */}
                      <div className="flex items-center gap-2 mt-3">
                        <div className="flex items-center border border-slate-200 rounded-lg">
                          <button
                            onClick={() =>
                              onUpdateQuantity(item.productId, Math.max(1, item.quantity - 1))
                            }
                            className="px-2 py-1 text-slate-600 hover:bg-slate-100"
                          >
                            −
                          </button>
                          <input
                            type="number"
                            min="1"
                            value={item.quantity}
                            onChange={(e) =>
                              onUpdateQuantity(
                                item.productId,
                                Math.max(1, parseInt(e.target.value) || 1)
                              )
                            }
                            className="w-8 text-center text-xs border-0 focus:outline-none"
                          />
                          <button
                            onClick={() => onUpdateQuantity(item.productId, item.quantity + 1)}
                            className="px-2 py-1 text-slate-600 hover:bg-slate-100"
                          >
                            +
                          </button>
                        </div>

                        <button
                          onClick={() => onRemoveItem(item.productId)}
                          className="ml-auto text-xs font-medium text-red-600 hover:text-red-700"
                        >
                          Remove
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Footer */}
        {items.length > 0 && (
          <div className="border-t border-slate-200 p-6 space-y-4 bg-slate-50">
            {/* Summary */}
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span className="text-slate-600">Subtotal</span>
                <span className="font-medium text-slate-900">${total.toFixed(2)}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-slate-600">Shipping</span>
                <span className="font-medium text-slate-900">Calculated at checkout</span>
              </div>
            </div>

            {/* Total */}
            <div className="pt-2 border-t border-slate-200">
              <div className="flex justify-between">
                <span className="font-semibold text-slate-900">Total</span>
                <span className="text-lg font-bold text-slate-900">
                  ${total.toFixed(2)}
                </span>
              </div>
            </div>

            {/* Checkout Button */}
            <button
              onClick={onCheckout}
              className="w-full py-3 px-4 bg-slate-900 text-white font-semibold rounded-lg hover:bg-slate-800 transition-colors"
            >
              Proceed to Checkout
            </button>
            <button
              onClick={onClose}
              className="w-full py-2 px-4 border border-slate-200 text-slate-900 font-medium rounded-lg hover:bg-slate-50 transition-colors"
            >
              Continue Shopping
            </button>
          </div>
        )}
      </div>
    </>
  );
};
