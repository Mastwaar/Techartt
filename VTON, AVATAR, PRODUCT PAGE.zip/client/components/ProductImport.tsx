import React, { useState } from "react";
import { Upload, Link as LinkIcon, X } from "lucide-react";
import { Product } from "@shared/api";

interface ProductImportProps {
  isOpen: boolean;
  onClose: () => void;
  onProductsImported: (products: Product[]) => void;
}

export const ProductImport: React.FC<ProductImportProps> = ({
  isOpen,
  onClose,
  onProductsImported,
}) => {
  const [importMethod, setImportMethod] = useState<"file" | "json" | "sheet">("file");
  const [jsonInput, setJsonInput] = useState("");
  const [sheetLink, setSheetLink] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState("");

  if (!isOpen) return null;

  // Simple CSV parser that handles quoted fields and various delimiters
  const parseCSV = (text: string): any[] => {
    const lines = text.trim().split("\n");
    if (lines.length < 2) {
      throw new Error("CSV file must have at least a header row and one data row");
    }

    const headers = parseCSVLine(lines[0]);
    const products: any[] = [];

    for (let i = 1; i < lines.length; i++) {
      const line = lines[i].trim();
      if (!line) continue;

      const values = parseCSVLine(line);
      const product: any = {};

      headers.forEach((header, index) => {
        const cleanHeader = header.trim();
        product[cleanHeader] = values[index]?.trim() || "";
      });

      if (product.Title || product.name) {
        products.push(product);
      }
    }

    return products;
  };

  // Parse a CSV line handling quoted fields and multiple delimiters
  const parseCSVLine = (line: string): string[] => {
    const result: string[] = [];
    let current = "";
    let insideQuotes = false;
    let delimiter = ","; // Default to comma

    // Detect delimiter (tab, comma, or semicolon)
    if (line.includes("\t")) delimiter = "\t";
    else if (line.includes(";")) delimiter = ";";

    for (let i = 0; i < line.length; i++) {
      const char = line[i];
      const nextChar = line[i + 1];

      if (char === '"') {
        if (insideQuotes && nextChar === '"') {
          current += '"';
          i++;
        } else {
          insideQuotes = !insideQuotes;
        }
      } else if (char === delimiter && !insideQuotes) {
        result.push(current);
        current = "";
      } else {
        current += char;
      }
    }

    result.push(current);
    return result;
  };

  const handleFileUpload = async (file: File) => {
    setIsLoading(true);
    setError("");

    try {
      const text = await file.text();
      const products = parseCSV(text);

      if (products.length === 0) {
        setError("No products found in file");
        setIsLoading(false);
        return;
      }

      console.log(`Parsed ${products.length} products from CSV:`, products);

      const response = await fetch("/api/products/import", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ products }),
      });

      const data = await response.json();
      console.log("Import response:", data);

      if (response.ok && data.products && data.products.length > 0) {
        onProductsImported(data.products);
        onClose();
      } else {
        setError(
          data.error ||
          `${data.count || 0}/${products.length} products imported. Check that each product has: Title, Pictures (image URLs), and Price.`
        );
      }
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setIsLoading(false);
    }
  };

  const handleJsonImport = async () => {
    setIsLoading(true);
    setError("");

    try {
      const products = JSON.parse(jsonInput);
      const response = await fetch("/api/products/import", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ products: Array.isArray(products) ? products : [products] }),
      });

      const data = await response.json();
      if (response.ok && data.products && data.products.length > 0) {
        onProductsImported(data.products);
        onClose();
      } else {
        setError(
          data.error ||
          "No valid products imported. Ensure each product has valid image URLs in the Pictures field."
        );
      }
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setIsLoading(false);
    }
  };

  const handleGoogleSheetsImport = async () => {
    setError("Google Sheets import coming soon. Use JSON or CSV import for now.");
  };

  return (
    <>
      {/* Overlay */}
      <div className="fixed inset-0 bg-black/50 z-40" onClick={onClose} />

      {/* Modal */}
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
        <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-xl max-w-2xl w-full max-h-96 overflow-y-auto">
          {/* Header */}
          <div className="flex items-center justify-between p-6 border-b border-slate-200 dark:border-slate-700 sticky top-0 bg-white dark:bg-slate-900">
            <h2 className="text-2xl font-bold text-slate-900 dark:text-white">
              Import Products
            </h2>
            <button
              onClick={onClose}
              className="p-2 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition-colors"
            >
              <X size={24} />
            </button>
          </div>

          {/* Content */}
          <div className="p-6 space-y-6">
            {error && (
              <div className="p-4 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-lg text-red-600 dark:text-red-400 text-sm">
                {error}
              </div>
            )}

            {/* Import Methods */}
            <div className="space-y-4">
              {/* CSV File Upload */}
              <div className="border-2 border-dashed border-slate-300 dark:border-slate-600 rounded-lg p-6 hover:border-purple-400 dark:hover:border-purple-500 transition-colors cursor-pointer group">
                <label className="flex items-center gap-3 cursor-pointer">
                  <div className="p-3 bg-purple-100 dark:bg-purple-900/30 rounded-lg group-hover:bg-purple-200 dark:group-hover:bg-purple-900/50 transition-colors">
                    <Upload className="text-purple-600 dark:text-purple-400" size={24} />
                  </div>
                  <div>
                    <h3 className="font-semibold text-slate-900 dark:text-white">
                      Upload CSV or Excel File
                    </h3>
                    <p className="text-sm text-slate-600 dark:text-slate-400">
                      Supports comma, tab, or semicolon delimiters
                    </p>
                  </div>
                  <input
                    type="file"
                    accept=".csv,.xlsx,.xls,.tsv"
                    onChange={(e) => e.target.files?.[0] && handleFileUpload(e.target.files[0])}
                    className="hidden"
                  />
                </label>
              </div>

              {/* JSON Input */}
              <div>
                <h3 className="font-semibold text-slate-900 dark:text-white mb-2">
                  Paste JSON Data
                </h3>
                <textarea
                  value={jsonInput}
                  onChange={(e) => setJsonInput(e.target.value)}
                  placeholder={`[{"Title":"Product 1","Price":99.99,"Pictures":"https://example.com/photo.jpg","Category":"Category"}]`}
                  className="w-full h-32 p-3 border border-slate-300 dark:border-slate-600 rounded-lg bg-white dark:bg-slate-800 text-slate-900 dark:text-white placeholder-slate-500 dark:placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-purple-500"
                />
                <button
                  onClick={handleJsonImport}
                  disabled={!jsonInput || isLoading}
                  className="mt-2 px-4 py-2 bg-purple-600 hover:bg-purple-700 disabled:opacity-50 text-white rounded-lg font-medium transition-colors"
                >
                  {isLoading ? "Importing..." : "Import JSON"}
                </button>
              </div>

              {/* Google Sheets */}
              <div>
                <h3 className="font-semibold text-slate-900 dark:text-white mb-2 flex items-center gap-2">
                  <LinkIcon size={18} />
                  Google Sheets Link
                </h3>
                <input
                  type="url"
                  value={sheetLink}
                  onChange={(e) => setSheetLink(e.target.value)}
                  placeholder="https://docs.google.com/spreadsheets/d/..."
                  className="w-full p-3 border border-slate-300 dark:border-slate-600 rounded-lg bg-white dark:bg-slate-800 text-slate-900 dark:text-white placeholder-slate-500 dark:placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-purple-500"
                />
                <p className="text-xs text-slate-600 dark:text-slate-400 mt-2">
                  Make sure the sheet is publicly accessible. Feature coming soon.
                </p>
                <button
                  onClick={handleGoogleSheetsImport}
                  disabled={!sheetLink || isLoading}
                  className="mt-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white rounded-lg font-medium transition-colors"
                >
                  {isLoading ? "Importing..." : "Import from Google Sheets"}
                </button>
              </div>
            </div>

            {/* Example Format */}
            <div className="bg-slate-50 dark:bg-slate-800 p-4 rounded-lg space-y-3">
              <div>
                <h4 className="font-medium text-slate-900 dark:text-white mb-2">
                  ✓ Required Columns:
                </h4>
                <code className="text-xs text-slate-600 dark:text-slate-400 block mb-2">
                  Title, Pictures, Price, Category, Size, Color, Description
                </code>
              </div>
              <div>
                <h4 className="font-medium text-slate-900 dark:text-white mb-2">
                  ✓ Pictures Column:
                </h4>
                <p className="text-xs text-slate-600 dark:text-slate-400">
                  Use full image URLs (https://...). Multiple images separated by commas in quotes: "url1.jpg,url2.jpg"
                </p>
              </div>
              <div>
                <h4 className="font-medium text-slate-900 dark:text-white mb-2">
                  ✓ CSV Example:
                </h4>
                <code className="text-xs text-slate-600 dark:text-slate-400 block whitespace-pre-wrap">
Title,Pictures,Price,Category
Classic Shirt,"https://images.unsplash.com/photo.jpg",49.99,Tops
Blue Jacket,"https://images.unsplash.com/photo2.jpg",99.99,Jackets
                </code>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};
