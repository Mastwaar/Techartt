import React, { useState } from "react";
import { Product, ProductVariant } from "@shared/api";
import { ShoppingBag, Eye, Heart } from "lucide-react";

interface ProductCardProps {
  product: Product;
  onAddToCart?: (product: Product, quantity: number, selectedVariants?: Record<string, string>) => void;
  onTryOn?: (product: Product) => void;
}

export const ProductCard: React.FC<ProductCardProps> = ({
  product,
  onAddToCart,
  onTryOn,
}) => {
  const [quantity, setQuantity] = useState(1);
  const [selectedVariants, setSelectedVariants] = useState<Record<string, string>>({});
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const [isWishlisted, setIsWishlisted] = useState(false);
  const [failedImages, setFailedImages] = useState<Set<number>>(new Set());

  const handleAddToCart = () => {
    onAddToCart?.(product, quantity, selectedVariants);
    setQuantity(1);
    setSelectedVariants({});
  };

  const handleVariantChange = (variantKey: string, value: string) => {
    setSelectedVariants((prev) => ({
      ...prev,
      [variantKey]: value,
    }));
  };

  const nextImage = () => {
    if (product.images.length > 1) {
      setCurrentImageIndex((prev) => (prev + 1) % product.images.length);
    }
  };

  const prevImage = () => {
    if (product.images.length > 1) {
      setCurrentImageIndex(
        (prev) => (prev - 1 + product.images.length) % product.images.length
      );
    }
  };

  const handleImageError = (index: number) => {
    const newFailed = new Set(failedImages);
    newFailed.add(index);
    setFailedImages(newFailed);

    // Try next image if available
    if (index === currentImageIndex && product.images.length > 1) {
      for (let i = 1; i < product.images.length; i++) {
        const nextIdx = (currentImageIndex + i) % product.images.length;
        if (!newFailed.has(nextIdx)) {
          setCurrentImageIndex(nextIdx);
          return;
        }
      }
    }
  };

  const currentImage = product.images[currentImageIndex];
  const hasValidImage = currentImage && !failedImages.has(currentImageIndex);

  return (
    <div className="group flex flex-col h-full bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl overflow-hidden hover:shadow-xl hover:shadow-purple-500/10 dark:hover:shadow-purple-500/20 transition-all duration-300">
      {/* Image Section */}
      <div className="relative bg-gradient-to-br from-slate-100 to-slate-50 dark:from-slate-800 dark:to-slate-700 aspect-square overflow-hidden flex items-center justify-center">
        {hasValidImage ? (
          <img
            src={currentImage}
            alt={product.name}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
            onError={() => handleImageError(currentImageIndex)}
          />
        ) : (
          <div className="flex flex-col items-center justify-center text-slate-400 dark:text-slate-500">
            <ShoppingBag size={32} className="mb-2 opacity-50" />
            <p className="text-xs text-center">Image unavailable</p>
          </div>
        )}

        {/* Wishlist Button */}
        <button
          onClick={() => setIsWishlisted(!isWishlisted)}
          className="absolute top-3 right-3 p-2 rounded-full bg-white/90 dark:bg-slate-800/90 hover:bg-white dark:hover:bg-slate-700 transition-all shadow-md hover:shadow-lg"
        >
          <Heart
            size={20}
            className={`transition-colors ${
              isWishlisted ? "fill-red-500 text-red-500" : "text-slate-600 dark:text-slate-300"
            }`}
          />
        </button>

        {/* Image Navigation */}
        {product.images.length > 1 && (
          <>
            <button
              onClick={prevImage}
              className="absolute left-3 top-1/2 -translate-y-1/2 p-2 rounded-full bg-white/80 dark:bg-slate-800/80 hover:bg-white dark:hover:bg-slate-700 text-slate-900 dark:text-white opacity-0 group-hover:opacity-100 transition-opacity shadow-md hover:shadow-lg"
            >
              ‹
            </button>
            <button
              onClick={nextImage}
              className="absolute right-3 top-1/2 -translate-y-1/2 p-2 rounded-full bg-white/80 dark:bg-slate-800/80 hover:bg-white dark:hover:bg-slate-700 text-slate-900 dark:text-white opacity-0 group-hover:opacity-100 transition-opacity shadow-md hover:shadow-lg"
            >
              ›
            </button>

            {/* Image Indicators */}
            <div className="absolute bottom-3 left-1/2 -translate-x-1/2 flex gap-1.5">
              {product.images.map((image, index) => (
                <button
                  key={`${product.id}-image-${index}`}
                  onClick={() => setCurrentImageIndex(index)}
                  className={`w-2.5 h-2.5 rounded-full transition-all ${
                    index === currentImageIndex
                      ? "bg-purple-500 w-8"
                      : "bg-white/60 hover:bg-white/80"
                  }`}
                />
              ))}
            </div>
          </>
        )}

        {/* Category Badge */}
        {product.category && (
          <div className="absolute top-3 left-3 px-3 py-1 bg-purple-600/90 dark:bg-purple-500/80 text-white text-xs font-semibold rounded-full">
            {product.category}
          </div>
        )}
      </div>

      {/* Content Section */}
      <div className="p-5 flex-1 flex flex-col">
        {/* Product Info */}
        <div className="flex-1">
          <h3 className="font-bold text-lg text-slate-900 dark:text-white line-clamp-2 mb-1">
            {product.name}
          </h3>
          {product.description && (
            <p className="text-xs text-slate-600 dark:text-slate-400 line-clamp-2 mb-3">
              {product.description}
            </p>
          )}

          {/* Price */}
          <div className="mb-4">
            <p className="text-2xl font-bold text-transparent bg-gradient-to-r from-purple-600 to-blue-600 dark:from-purple-400 dark:to-blue-400 bg-clip-text">
              ${product.price.toFixed(2)}
            </p>
          </div>

          {/* Variants */}
          {product.variants && Object.entries(product.variants).length > 0 && (
            <div className="mt-4 space-y-3">
              {Object.entries(product.variants).map(([variantKey, variants]) => (
                <div key={variantKey}>
                  <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 uppercase tracking-wider block mb-2">
                    {variantKey}
                  </label>
                  <div className="flex gap-2 flex-wrap">
                    {variants.map((variant) => (
                      <button
                        key={`${product.id}-${variantKey}-${variant.id}`}
                        onClick={() => handleVariantChange(variantKey, variant.value)}
                        className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-all border-2 ${
                          selectedVariants[variantKey] === variant.value
                            ? "bg-gradient-to-r from-purple-600 to-blue-600 text-white border-transparent shadow-lg shadow-purple-500/50"
                            : "bg-slate-50 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-300 dark:border-slate-600 hover:border-purple-400 dark:hover:border-purple-500"
                        }`}
                        disabled={variant.stock === 0}
                      >
                        {variant.name}
                      </button>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Quantity Selector */}
        <div className="mt-4 flex items-center gap-3">
          <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 uppercase tracking-wider">
            Qty
          </label>
          <div className="flex items-center border-2 border-slate-300 dark:border-slate-600 rounded-lg overflow-hidden hover:border-purple-400 dark:hover:border-purple-500 transition-colors">
            <button
              onClick={() => setQuantity(Math.max(1, quantity - 1))}
              className="px-2 py-1 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 font-bold"
            >
              −
            </button>
            <input
              type="number"
              min="1"
              value={quantity}
              onChange={(e) => setQuantity(Math.max(1, parseInt(e.target.value) || 1))}
              className="w-12 text-center text-sm font-medium border-0 bg-transparent text-slate-900 dark:text-white focus:outline-none"
            />
            <button
              onClick={() => setQuantity(quantity + 1)}
              className="px-2 py-1 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 font-bold"
            >
              +
            </button>
          </div>
        </div>

        {/* Actions */}
        <div className="mt-5 flex gap-2">
          {product.vtonImage && (
            <button
              onClick={() => onTryOn?.(product)}
              className="flex-1 py-2.5 px-3 text-xs font-semibold text-purple-600 dark:text-purple-400 bg-purple-50 dark:bg-purple-900/20 hover:bg-purple-100 dark:hover:bg-purple-900/40 rounded-lg transition-all border border-purple-200 dark:border-purple-800 hover:border-purple-300 dark:hover:border-purple-700 flex items-center justify-center gap-1.5"
            >
              <Eye size={16} />
              Try On
            </button>
          )}
          <button
            onClick={handleAddToCart}
            className="flex-1 py-2.5 px-3 text-xs font-semibold text-white bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 dark:from-purple-500 dark:to-blue-500 dark:hover:from-purple-600 dark:hover:to-blue-600 rounded-lg transition-all shadow-lg shadow-purple-500/30 hover:shadow-purple-500/50 flex items-center justify-center gap-1.5"
          >
            <ShoppingBag size={16} />
            Add Cart
          </button>
        </div>
      </div>
    </div>
  );
};
