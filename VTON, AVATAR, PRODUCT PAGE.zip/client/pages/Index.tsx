import { useState, useEffect } from "react";
import { ShoppingBag, Moon, Sun, Upload } from "lucide-react";
import { Avatar } from "@/components/Avatar";
import { ProductCard } from "@/components/ProductCard";
import { Cart } from "@/components/Cart";
import { ProductImport } from "@/components/ProductImport";
import { useCart } from "@/context/CartContext";
import { useTheme } from "@/context/ThemeContext";
import { Product, AppliedProduct } from "@shared/api";
import { useNavigate } from "react-router-dom";

export default function Index() {
  const [products, setProducts] = useState<Product[]>([]);
  const [appliedProducts, setAppliedProducts] = useState<AppliedProduct[]>([]);
  const [cartOpen, setCartOpen] = useState(false);
  const [importOpen, setImportOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const { items, addItem, removeItem, updateQuantity, cartTotal } = useCart();
  const { isDark, toggleTheme } = useTheme();
  const navigate = useNavigate();

  // Fetch products on mount
  useEffect(() => {
    fetchProducts();
  }, []);

  const fetchProducts = async () => {
    try {
      const response = await fetch("/api/products");
      const data = await response.json();
      setProducts(data.products || []);
    } catch (error) {
      console.error("Failed to fetch products:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleAddToCart = (
    product: Product,
    quantity: number,
    selectedVariants?: Record<string, string>
  ) => {
    addItem(product, quantity, selectedVariants);
  };

  const handleTryOn = (product: Product) => {
    if (product.vtonImage) {
      const appliedProduct: AppliedProduct = {
        productId: product.id,
        layer: "top",
        imageUrl: product.vtonImage,
      };
      setAppliedProducts((prev) => {
        const existing = prev.find((p) => p.productId === product.id);
        if (existing) {
          return prev.filter((p) => p.productId !== product.id);
        }
        return [...prev, appliedProduct];
      });
    }
  };

  const handleRemoveProduct = (productId: string) => {
    setAppliedProducts((prev) => prev.filter((p) => p.productId !== productId));
  };

  const handleCheckout = () => {
    setCartOpen(false);
    navigate("/checkout");
  };

  const handleProductsImported = (importedProducts: Product[]) => {
    setProducts(importedProducts);
  };

  return (
    <div className="min-h-screen bg-white dark:bg-slate-950 flex flex-col transition-colors duration-300">
      {/* Header */}
      <header className="border-b border-slate-200 dark:border-slate-800 sticky top-0 bg-white dark:bg-slate-950 z-30 transition-colors duration-300">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="inline-flex items-center justify-center w-10 h-10 rounded-lg bg-gradient-to-r from-purple-600 to-blue-600">
              <ShoppingBag className="text-white" size={24} />
            </div>
            <h1 className="text-2xl font-bold text-transparent bg-gradient-to-r from-purple-600 to-blue-600 dark:from-purple-400 dark:to-blue-400 bg-clip-text">
              StyleHub
            </h1>
          </div>

          <div className="flex items-center gap-3">
            {/* Import Products Button */}
            <button
              onClick={() => setImportOpen(true)}
              className="hidden sm:flex items-center gap-2 px-4 py-2 text-sm font-semibold text-purple-600 dark:text-purple-400 bg-purple-50 dark:bg-purple-900/20 hover:bg-purple-100 dark:hover:bg-purple-900/40 rounded-lg transition-colors border border-purple-200 dark:border-purple-800"
            >
              <Upload size={16} />
              Import
            </button>

            {/* Dark/Light Toggle */}
            <button
              onClick={toggleTheme}
              className="p-2.5 text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition-colors border border-slate-200 dark:border-slate-700"
              title={isDark ? "Switch to light mode" : "Switch to dark mode"}
            >
              {isDark ? <Sun size={20} /> : <Moon size={20} />}
            </button>

            {/* Cart Button */}
            <button
              onClick={() => setCartOpen(true)}
              className="relative p-2.5 text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition-colors border border-slate-200 dark:border-slate-700"
            >
              <ShoppingBag size={24} />
              {items.length > 0 && (
                <span className="absolute top-0 right-0 w-5 h-5 bg-gradient-to-r from-purple-600 to-red-600 text-white text-xs rounded-full flex items-center justify-center font-bold">
                  {items.length}
                </span>
              )}
            </button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 overflow-hidden">
        <div className="h-full flex">
          {/* Left Panel - Avatar (30-35% width) */}
          <div className="hidden lg:flex h-full w-[35%] flex-shrink-0 border-r border-slate-200 dark:border-slate-800">
            <Avatar
              appliedProducts={appliedProducts}
              onRemoveProduct={handleRemoveProduct}
              onClearAll={() => setAppliedProducts([])}
            />
          </div>

          {/* Right Panel - Products */}
          <div className="flex-1 overflow-y-auto">
            <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
              {/* Section Header */}
              <div className="mb-12">
                <h2 className="text-4xl sm:text-5xl font-bold text-slate-900 dark:text-white mb-3">
                  Featured Collection
                </h2>
                <p className="text-lg text-slate-600 dark:text-slate-400">
                  {products.length > 0
                    ? `Discover ${products.length} premium items`
                    : "Import products to get started"}
                </p>
              </div>

              {/* Products Grid or Empty State */}
              {isLoading ? (
                <div className="flex items-center justify-center py-20">
                  <div className="text-center">
                    <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-purple-100 dark:bg-purple-900/20 mb-4">
                      <ShoppingBag className="text-purple-600 dark:text-purple-400 animate-pulse" size={32} />
                    </div>
                    <p className="text-slate-600 dark:text-slate-400">Loading products...</p>
                  </div>
                </div>
              ) : products.length === 0 ? (
                <div className="flex items-center justify-center py-20">
                  <div className="text-center">
                    <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-purple-100 dark:bg-purple-900/20 mb-4">
                      <Upload className="text-purple-600 dark:text-purple-400" size={32} />
                    </div>
                    <h3 className="text-2xl font-bold text-slate-900 dark:text-white mb-2">
                      No Products Yet
                    </h3>
                    <p className="text-slate-600 dark:text-slate-400 mb-6">
                      Import your products from Excel, CSV, or JSON to get started
                    </p>
                    <button
                      onClick={() => setImportOpen(true)}
                      className="px-6 py-3 bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white font-semibold rounded-lg transition-all shadow-lg shadow-purple-500/30"
                    >
                      Import Products
                    </button>
                  </div>
                </div>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
                  {products.map((product) => (
                    <ProductCard
                      key={product.id}
                      product={product}
                      onAddToCart={handleAddToCart}
                      onTryOn={handleTryOn}
                    />
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      </main>

      {/* Cart Slide-over */}
      <Cart
        items={items}
        total={cartTotal}
        isOpen={cartOpen}
        onClose={() => setCartOpen(false)}
        onUpdateQuantity={updateQuantity}
        onRemoveItem={removeItem}
        onCheckout={handleCheckout}
      />

      {/* Product Import Modal */}
      <ProductImport
        isOpen={importOpen}
        onClose={() => setImportOpen(false)}
        onProductsImported={handleProductsImported}
      />
    </div>
  );
}
