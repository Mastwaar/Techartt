import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { ChevronLeft } from "lucide-react";
import { VTONPreview } from "@/components/VTONPreview";
import { CheckoutForm } from "@/components/CheckoutForm";
import { useCart } from "@/context/CartContext";
import { CheckoutOrderPayload } from "@shared/api";

export default function Checkout() {
  const navigate = useNavigate();
  const { items, cartTotal, clearCart } = useCart();
  const [userImage, setUserImage] = useState<string | undefined>();
  const [isProcessing, setIsProcessing] = useState(false);

  // Prepare products for VTON with vtonImage fallback
  const vtonProducts = items
    .filter((item) => item.product.vtonImage)
    .map((item) => ({
      productId: item.productId,
      overlayImage: item.product.vtonImage!,
      name: item.product.name,
    }));

  const handleCheckoutSubmit = async (payload: CheckoutOrderPayload) => {
    setIsProcessing(true);
    try {
      // Here you would call your payment API
      // For example:
      // const response = await fetch('/api/checkout', {
      //   method: 'POST',
      //   headers: { 'Content-Type': 'application/json' },
      //   body: JSON.stringify(payload)
      // });

      // Simulating API call
      await new Promise((resolve) => setTimeout(resolve, 1500));

      // Clear cart and redirect to success page
      clearCart();
      navigate("/order-success", {
        state: { order: payload },
      });
    } catch (error) {
      console.error("Checkout error:", error);
      setIsProcessing(false);
    }
  };

  // Redirect to home if cart is empty
  if (items.length === 0) {
    return (
      <div className="min-h-screen bg-white flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-slate-900 mb-2">Your cart is empty</h2>
          <p className="text-slate-600 mb-6">Add items to proceed to checkout</p>
          <button
            onClick={() => navigate("/")}
            className="inline-flex items-center gap-2 px-6 py-3 bg-slate-900 text-white font-semibold rounded-lg hover:bg-slate-800 transition-colors"
          >
            <ChevronLeft size={20} />
            Back to Shopping
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Header */}
      <header className="bg-white border-b border-slate-200 sticky top-0 z-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <button
            onClick={() => navigate("/")}
            className="inline-flex items-center gap-2 text-slate-600 hover:text-slate-900 font-medium mb-4"
          >
            <ChevronLeft size={20} />
            Back to Shopping
          </button>
          <h1 className="text-2xl font-bold text-slate-900">Checkout</h1>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Left Column - VTON and Form */}
          <div className="space-y-8">
            {/* Virtual Try-On Section */}
            <VTONPreview
              userImage={userImage}
              products={vtonProducts}
              onUserImageUpload={setUserImage}
            />

            {/* Checkout Form */}
            <CheckoutForm
              items={items}
              subtotal={cartTotal}
              onSubmit={handleCheckoutSubmit}
              isLoading={isProcessing}
            />
          </div>

          {/* Right Column - Order Summary */}
          <div className="lg:sticky lg:top-24 lg:h-max">
            <div className="bg-white rounded-lg border border-slate-200 overflow-hidden">
              {/* Header */}
              <div className="p-6 border-b border-slate-200">
                <h3 className="text-lg font-semibold text-slate-900">Order Summary</h3>
              </div>

              {/* Items */}
              <div className="divide-y divide-slate-100">
                {items.map((item) => (
                  <div key={item.productId} className="p-4">
                    <div className="flex gap-4">
                      {/* Image */}
                      <div className="w-16 h-16 bg-slate-100 rounded-lg overflow-hidden flex-shrink-0">
                        <img
                          src={item.product.images[0]}
                          alt={item.product.name}
                          className="w-full h-full object-cover"
                        />
                      </div>

                      {/* Details */}
                      <div className="flex-1 min-w-0">
                        <h4 className="font-medium text-slate-900 line-clamp-2 text-sm">
                          {item.product.name}
                        </h4>

                        {item.selectedVariants &&
                          Object.entries(item.selectedVariants).length > 0 && (
                            <div className="mt-1">
                              {Object.entries(item.selectedVariants).map(([key, value]) => (
                                <p key={key} className="text-xs text-slate-500">
                                  {key}: {value}
                                </p>
                              ))}
                            </div>
                          )}

                        <div className="flex items-center gap-2 mt-2">
                          <span className="text-xs text-slate-500">Qty: {item.quantity}</span>
                          <span className="text-sm font-semibold text-slate-900">
                            ${(item.product.price * item.quantity).toFixed(2)}
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              {/* Pricing Section */}
              <div className="p-6 border-t border-slate-200 bg-slate-50 space-y-3">
                <div className="flex justify-between text-sm">
                  <span className="text-slate-600">Subtotal</span>
                  <span className="font-medium text-slate-900">${cartTotal.toFixed(2)}</span>
                </div>

                <div className="flex justify-between text-sm">
                  <span className="text-slate-600">Shipping</span>
                  <span className="font-medium text-slate-900">
                    {cartTotal > 0 ? "$10.00" : "Free"}
                  </span>
                </div>

                <div className="flex justify-between text-sm">
                  <span className="text-slate-600">Tax (10%)</span>
                  <span className="font-medium text-slate-900">
                    ${(cartTotal * 0.1).toFixed(2)}
                  </span>
                </div>

                <div className="border-t border-slate-200 pt-3 flex justify-between">
                  <span className="font-semibold text-slate-900">Total</span>
                  <span className="text-xl font-bold text-slate-900">
                    ${(cartTotal + (cartTotal > 0 ? 10 : 0) + cartTotal * 0.1).toFixed(2)}
                  </span>
                </div>
              </div>

              {/* Trust Badges */}
              <div className="p-6 border-t border-slate-200 space-y-2">
                <div className="flex items-center gap-2 text-xs text-slate-600">
                  <svg
                    className="w-4 h-4"
                    fill="currentColor"
                    viewBox="0 0 20 20"
                  >
                    <path
                      fillRule="evenodd"
                      d="M5 9V7a5 5 0 0110 0v2a2 2 0 012 2v5a2 2 0 01-2 2H5a2 2 0 01-2-2v-5a2 2 0 012-2zm8-2v2H7V7a3 3 0 016 0z"
                      clipRule="evenodd"
                    />
                  </svg>
                  Secure & encrypted payment
                </div>
                <div className="flex items-center gap-2 text-xs text-slate-600">
                  <svg
                    className="w-4 h-4"
                    fill="currentColor"
                    viewBox="0 0 20 20"
                  >
                    <path d="M9 2a1 1 0 000 2h2a1 1 0 100-2H9z" />
                    <path
                      fillRule="evenodd"
                      d="M4 5a2 2 0 012-2 1 1 0 000 2H3a1 1 0 00-1 1v12a1 1 0 001 1h14a1 1 0 001-1V6a1 1 0 00-1-1h-3a1 1 0 000-2h2a2 2 0 012 2v12a2 2 0 01-2 2H4a2 2 0 01-2-2V5z"
                      clipRule="evenodd"
                    />
                  </svg>
                  Easy returns within 30 days
                </div>
                <div className="flex items-center gap-2 text-xs text-slate-600">
                  <svg
                    className="w-4 h-4"
                    fill="currentColor"
                    viewBox="0 0 20 20"
                  >
                    <path d="M8 16.5a1.5 1.5 0 11-3 0 1.5 1.5 0 013 0zM15 16.5a1.5 1.5 0 11-3 0 1.5 1.5 0 013 0z" />
                    <path d="M3 4a1 1 0 00-1 1v10a1 1 0 001 1h1.05a2.5 2.5 0 014.9 0H10a1 1 0 001-1V5a1 1 0 00-1-1H3zM14 7a1 1 0 00-1 1v6.05A2.5 2.5 0 0115.95 16H17a1 1 0 001-1v-5a1 1 0 00-.293-.707l-2-2A1 1 0 0015 7h-1z" />
                  </svg>
                  Fast & reliable shipping
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
