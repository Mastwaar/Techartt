import { RequestHandler } from "express";
import { Product } from "@shared/api";

// In-memory storage for products (in production, use a database)
let storedProducts: Product[] = [];

/**
 * GET /api/products - Get all products
 */
export const getProducts: RequestHandler = (req, res) => {
  res.json({ products: storedProducts });
};

/**
 * Helper to validate and clean image URLs
 * More lenient - accepts URLs even if not perfectly formatted
 */
function isValidImageUrl(url: string): boolean {
  if (!url || typeof url !== "string") return false;
  const trimmed = url.trim();
  if (!trimmed) return false;

  // Accept anything that looks like a URL or file path
  // Must start with http/https or have a file extension
  const isUrl = /^https?:\/\/.+/i.test(trimmed);
  const isImageFile = /\.(jpg|jpeg|png|gif|webp|svg)($|\?)/i.test(trimmed);

  return isUrl || isImageFile;
}

/**
 * Parse image URLs - handles various formats
 */
function parseImages(imagesInput: any): string[] {
  if (!imagesInput) return [];

  let images: string[] = [];

  if (Array.isArray(imagesInput)) {
    images = imagesInput.map((img: any) =>
      typeof img === "string" ? img.trim() : ""
    ).filter(Boolean);
  } else if (typeof imagesInput === "string") {
    // Remove surrounding quotes if present
    let cleaned = imagesInput.trim();
    if ((cleaned.startsWith('"') && cleaned.endsWith('"')) ||
        (cleaned.startsWith("'") && cleaned.endsWith("'"))) {
      cleaned = cleaned.slice(1, -1);
    }

    // Split by common delimiters: comma, semicolon, pipe
    images = cleaned
      .split(/[,;|]/)
      .map((img: string) => img.trim())
      .filter((img: string) => img.length > 0);
  }

  // Filter to only valid URLs
  const validImages = images.filter((img: string) => isValidImageUrl(img));

  console.log(
    `Parsed images for product:`,
    `Input: "${imagesInput}"`,
    `Found: ${validImages.length}/${images.length}`,
    `URLs: ${validImages.join(", ")}`
  );

  return validImages.slice(0, 5); // Max 5 images per product
}

/**
 * POST /api/products/import - Import products from array
 * Expects: { products: Product[] }
 */
export const importProducts: RequestHandler = (req, res) => {
  try {
    const { products } = req.body;

    if (!Array.isArray(products)) {
      return res.status(400).json({ error: "Products must be an array" });
    }

    // Validate and transform product data
    const validatedProducts: Product[] = products
      .map((product: any, idx: number) => {
        // Parse images - check multiple field names
        const imagesInput =
          product.images ||
          product.Pictures ||
          product.picture ||
          product.Image ||
          product.images_url ||
          product.picture_url ||
          "";

        console.log(
          `Processing product ${idx + 1}: "${product.Title || product.name}"`
        );

        const images = parseImages(imagesInput);

        // Skip products with no valid images
        if (images.length === 0) {
          console.warn(
            `⚠️  Skipping product "${product.Title || product.name}" (row ${idx + 1}) - no valid image URLs found. Received: "${imagesInput}"`
          );
          return null;
        }

        console.log(
          `✓ Product "${product.Title || product.name}" accepted with ${images.length} image(s)`
        );

        // Parse price safely
        let price = 0;
        const priceInput = product.Price || product.price || "0";
        if (typeof priceInput === "string") {
          price = parseFloat(priceInput.replace(/[^0-9.]/g, "")) || 0;
        } else {
          price = parseFloat(priceInput) || 0;
        }

        // Generate a unique ID for the product
        // Use title + random suffix to ensure uniqueness
        const baseId = (product.Title || product.name || "product").toLowerCase().replace(/\s+/g, "-");
        const uniqueId = `${baseId}-${Math.random().toString(36).substr(2, 9)}`;

        // Handle variants with unique IDs
        let variants: Record<string, any[]> = {};
        if (product.Size && product.Size.trim()) {
          const sizes = product.Size.split(/[,;|]/)
            .map((s: string) => s.trim())
            .filter((s: string) => s);
          if (sizes.length > 0) {
            variants.size = sizes.map((size: string) => ({
              id: `${uniqueId}-size-${size}`,
              name: size,
              value: size,
              stock: 10,
            }));
          }
        }
        if (product.Color && product.Color.trim()) {
          const colors = product.Color.split(/[,;|]/)
            .map((c: string) => c.trim())
            .filter((c: string) => c);
          if (colors.length > 0) {
            variants.color = colors.map((color: string) => ({
              id: `${uniqueId}-color-${color}`,
              name: color,
              value: color,
              stock: 10,
            }));
          }
        }

        return {
          id: uniqueId,
          name: (product.Title || product.name || "Untitled Product").trim(),
          price,
          description: (product.Description || product.description || "").trim(),
          images,
          variants: Object.keys(variants).length > 0 ? variants : undefined,
          category: (product.Category || product.category || "").trim(),
          vtonImage: images[0],
        };
      })
      .filter((p: any) => p !== null);

    if (validatedProducts.length === 0) {
      return res.status(400).json({
        error: "No valid products found. Ensure products have valid image URLs.",
      });
    }

    storedProducts = validatedProducts;
    res.json({
      success: true,
      count: validatedProducts.length,
      products: validatedProducts,
    });
  } catch (error) {
    console.error("Import error:", error);
    res.status(400).json({ error: (error as Error).message });
  }
};

/**
 * POST /api/products/import-from-csv - Import from CSV text
 */
export const importFromCSV: RequestHandler = (req, res) => {
  try {
    const { csvText } = req.body;

    if (!csvText || typeof csvText !== "string") {
      return res.status(400).json({ error: "CSV text is required" });
    }

    const lines = csvText.trim().split("\n");
    const headers = lines[0].split("\t").map((h) => h.trim());
    const products: any[] = [];

    for (let i = 1; i < lines.length; i++) {
      const values = lines[i].split("\t");
      const product: any = {};

      headers.forEach((header, index) => {
        product[header] = values[index]?.trim() || "";
      });

      if (product.Title || product.name) {
        products.push(product);
      }
    }

    // Use importProducts logic
    req.body = { products };
    return importProducts(req, res);
  } catch (error) {
    console.error("CSV import error:", error);
    res.status(400).json({ error: (error as Error).message });
  }
};
